﻿function newPopup(url) {

	var winTop = (screen.height / 2) - (400 / 2);
    var winLeft = (screen.width / 2) - (400/ 2);
	popupWindow = window.open(url,'popUpWindow','height=400 , width=400,left=' + winLeft + ',top=' + winTop + ',resizable=yes , scrollbars=no,toolbar=0,status=0,menubar=no,location=no,directories=no')
}
